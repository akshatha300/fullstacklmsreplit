# LMS Platform — Role-Based Learning Management System

## Overview

Full-stack LMS with student performance analytics. Spring Boot 3.2.5 backend, React+Vite frontend, PostgreSQL database.

## Architecture

pnpm monorepo with two artifacts:
- `artifacts/lms-backend/` — Spring Boot 3.2.5 (Java 19) REST API (runs via `artifacts/api-server` artifact slot)
- `artifacts/lms-frontend/` — React + Vite + Tailwind + shadcn/ui SPA
- `lib/api-spec/` — OpenAPI 3.1 contract
- `lib/api-client-react/` — Orval-generated React Query hooks
- `lib/api-zod/` — Orval-generated Zod schemas

## Stack

- **Backend**: Spring Boot 3.2.5, Java 19, Spring Security + JWT (HS512), Spring Data JPA, Hibernate
- **Database**: PostgreSQL (HikariCP pool)
- **Frontend**: React 18, Vite, Tailwind CSS, shadcn/ui, Recharts, Wouter, TanStack Query
- **API Contract**: OpenAPI 3.1 → Orval codegen
- **Security**: JWT Bearer token auth, role-based access control

## Roles & Seeded Accounts

| Role       | Email                   | Password        |
|------------|-------------------------|-----------------|
| ADMIN      | admin@lms.com           | admin123        |
| INSTRUCTOR | sarah@lms.com           | instructor123   |
| INSTRUCTOR | michael@lms.com         | instructor123   |
| STUDENT    | alice@lms.com           | student123      |

## Services

| Service        | Port  | Path  |
|----------------|-------|-------|
| Spring Boot API | 8090  | /api  |
| React Frontend  | auto  | /     |

## Key API Endpoints

- `POST /api/auth/login` — JWT login
- `POST /api/auth/register` — Register new user
- `GET /api/users` — All users (ADMIN)
- `GET /api/courses` — Public course catalog
- `POST /api/courses` — Create course (INSTRUCTOR)
- `GET /api/enrollments/my` — My enrollments
- `POST /api/enrollments/courses/{id}` — Enroll in course
- `GET /api/analytics/overview` — System analytics (ADMIN)
- `GET /api/analytics/my` — My analytics (STUDENT)
- `GET /api/healthz` — Health check

## Frontend Pages

- `/login`, `/register` — Auth
- `/dashboard/admin` — Admin: overview stats + charts
- `/dashboard/instructor` — Instructor: course list + management
- `/dashboard/student` — Student: progress + scores
- `/courses` — Course catalog with search/filter
- `/courses/:id` — Course detail + enrollment + modules
- `/courses/create` — Create new course (INSTRUCTOR)
- `/courses/:id/manage` — Manage course modules + assignments + grading (INSTRUCTOR)
- `/users` — User management (ADMIN)
- `/assignments` — My assignments + submissions (STUDENT)
- `/analytics/overview` — Full system analytics (ADMIN)
- `/analytics/my` — Personal analytics (STUDENT)
- `/analytics/students/:id` — Student analytics (ADMIN/INSTRUCTOR)
- `/analytics/courses/:id` — Course analytics (ADMIN/INSTRUCTOR)

## Key Commands

- `pnpm --filter @workspace/api-spec run codegen` — Regenerate API hooks from OpenAPI spec
- Spring Boot: `cd artifacts/lms-backend && mvn spring-boot:run`

## application.yml Config

Spring Boot reads: `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`, `PORT` (default 8090), `app.jwt.secret`.
`spring.jpa.hibernate.ddl-auto=update` — schema auto-created on startup.
Data seeder runs on startup if no users exist.
