import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { UserResponse } from "@workspace/api-zod";
import { setAuthTokenGetter } from "@workspace/api-client-react";

interface AuthState {
  token: string | null;
  user: UserResponse | null;
  isAuthenticated: boolean;
  role: "ADMIN" | "INSTRUCTOR" | "STUDENT" | null;
}

interface AuthContextType extends AuthState {
  login: (token: string, user: UserResponse) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(() => {
    const token = localStorage.getItem("token");
    const userStr = localStorage.getItem("user");
    let user = null;
    
    if (userStr) {
      try {
        user = JSON.parse(userStr);
      } catch (e) {
        console.error("Failed to parse user from localStorage", e);
      }
    }
    
    if (token) {
      setAuthTokenGetter(() => token);
    }
    
    return {
      token,
      user,
      isAuthenticated: !!token,
      role: user?.role || null,
    };
  });

  useEffect(() => {
    if (state.token) {
      localStorage.setItem("token", state.token);
      localStorage.setItem("user", JSON.stringify(state.user));
      setAuthTokenGetter(() => state.token);
    } else {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      setAuthTokenGetter(null);
    }
  }, [state.token, state.user]);

  const login = (token: string, user: UserResponse) => {
    setState({
      token,
      user,
      isAuthenticated: true,
      role: user.role,
    });
  };

  const logout = () => {
    setState({
      token: null,
      user: null,
      isAuthenticated: false,
      role: null,
    });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
