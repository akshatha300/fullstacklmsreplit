import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import Login from "@/pages/auth/login";
import Register from "@/pages/auth/register";
import AdminDashboard from "@/pages/dashboard/admin";
import InstructorDashboard from "@/pages/dashboard/instructor";
import StudentDashboard from "@/pages/dashboard/student";
import CourseCatalog from "@/pages/courses/index";
import CourseDetail from "@/pages/courses/detail";
import ManageCourse from "@/pages/courses/manage";
import CreateCourse from "@/pages/courses/create";
import UsersPage from "@/pages/users/index";
import AssignmentsPage from "@/pages/assignments/index";
import AnalyticsOverview from "@/pages/analytics/overview";
import MyAnalytics from "@/pages/analytics/my-analytics";
import StudentAnalytics from "@/pages/analytics/student-analytics";
import CourseAnalytics from "@/pages/analytics/course-analytics";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function ProtectedRoute({
  component: Component,
  allowedRoles,
}: {
  component: React.ComponentType;
  allowedRoles?: string[];
}) {
  const { isAuthenticated, role } = useAuth();

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  if (allowedRoles && role && !allowedRoles.includes(role)) {
    return <NotFound />;
  }

  return <Component />;
}

function RoleRedirect() {
  const { role, isAuthenticated } = useAuth();

  if (!isAuthenticated) return <Redirect to="/login" />;
  if (role === "ADMIN") return <Redirect to="/dashboard/admin" />;
  if (role === "INSTRUCTOR") return <Redirect to="/dashboard/instructor" />;
  if (role === "STUDENT") return <Redirect to="/dashboard/student" />;
  return <Redirect to="/courses" />;
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />

        <Route path="/">
          <RoleRedirect />
        </Route>

        <Route path="/dashboard/admin">
          <ProtectedRoute component={AdminDashboard} allowedRoles={["ADMIN"]} />
        </Route>
        <Route path="/dashboard/instructor">
          <ProtectedRoute component={InstructorDashboard} allowedRoles={["INSTRUCTOR"]} />
        </Route>
        <Route path="/dashboard/student">
          <ProtectedRoute component={StudentDashboard} allowedRoles={["STUDENT"]} />
        </Route>

        <Route path="/courses/create">
          <ProtectedRoute component={CreateCourse} allowedRoles={["INSTRUCTOR", "ADMIN"]} />
        </Route>
        <Route path="/courses/:id/manage">
          <ProtectedRoute component={ManageCourse} allowedRoles={["INSTRUCTOR", "ADMIN"]} />
        </Route>
        <Route path="/courses/:id">
          <ProtectedRoute component={CourseDetail} />
        </Route>
        <Route path="/courses">
          <ProtectedRoute component={CourseCatalog} />
        </Route>

        <Route path="/users">
          <ProtectedRoute component={UsersPage} allowedRoles={["ADMIN"]} />
        </Route>

        <Route path="/assignments">
          <ProtectedRoute component={AssignmentsPage} allowedRoles={["STUDENT"]} />
        </Route>

        <Route path="/analytics/overview">
          <ProtectedRoute component={AnalyticsOverview} allowedRoles={["ADMIN"]} />
        </Route>
        <Route path="/analytics/my">
          <ProtectedRoute component={MyAnalytics} allowedRoles={["STUDENT"]} />
        </Route>
        <Route path="/analytics/students/:id">
          <ProtectedRoute component={StudentAnalytics} allowedRoles={["ADMIN", "INSTRUCTOR"]} />
        </Route>
        <Route path="/analytics/courses/:id">
          <ProtectedRoute component={CourseAnalytics} allowedRoles={["ADMIN", "INSTRUCTOR"]} />
        </Route>

        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
