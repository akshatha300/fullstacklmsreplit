import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="font-bold text-xl text-primary">
              LMS Platform
            </Link>
            
            {isAuthenticated && (
              <nav className="flex items-center gap-4 text-sm font-medium">
                <Link href="/" className="text-muted-foreground hover:text-foreground">
                  Dashboard
                </Link>
                <Link href="/courses" className="text-muted-foreground hover:text-foreground">
                  Courses
                </Link>
                
                {user?.role === "ADMIN" && (
                  <>
                    <Link href="/users" className="text-muted-foreground hover:text-foreground">
                      Users
                    </Link>
                    <Link href="/analytics/overview" className="text-muted-foreground hover:text-foreground">
                      Analytics
                    </Link>
                  </>
                )}
                
                {user?.role === "INSTRUCTOR" && (
                  <Link href="/dashboard/instructor" className="text-muted-foreground hover:text-foreground">
                    My Courses
                  </Link>
                )}

                {user?.role === "STUDENT" && (
                  <>
                    <Link href="/assignments" className="text-muted-foreground hover:text-foreground">
                      Assignments
                    </Link>
                    <Link href="/analytics/my" className="text-muted-foreground hover:text-foreground">
                      My Analytics
                    </Link>
                  </>
                )}
              </nav>
            )}
          </div>
          
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <div className="text-sm">
                  <span className="font-medium">{user?.firstName} {user?.lastName}</span>
                  <span className="text-muted-foreground ml-2 text-xs border rounded px-1.5 py-0.5 bg-muted/50">
                    {user?.role}
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  Log out
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" asChild>
                  <Link href="/login">Login</Link>
                </Button>
                <Button asChild>
                  <Link href="/register">Register</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
}
