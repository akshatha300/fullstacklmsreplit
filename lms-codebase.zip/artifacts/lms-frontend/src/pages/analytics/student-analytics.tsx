import { useRoute, Link } from "wouter";
import { useGetStudentAnalytics } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ChevronLeft } from "lucide-react";

export default function StudentAnalytics() {
  const [, params] = useRoute("/analytics/students/:id");
  const id = Number(params?.id);
  const { data: analytics, isLoading } = useGetStudentAnalytics({ params: { id } });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-4 md:grid-cols-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!analytics) return <div className="text-destructive">Student not found</div>;

  const scoreData = analytics.recentSubmissions
    ?.filter(s => s.status === "GRADED")
    .map(s => ({
      name: s.assignmentTitle?.slice(0, 12) + "…" || "Assignment",
      pct: s.maxScore ? Math.round(((s.score!) / s.maxScore) * 100) : 0,
    })) ?? [];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/analytics/overview"><ChevronLeft className="h-4 w-4 mr-1" />Back</Link>
        </Button>
      </div>

      <h1 className="text-2xl font-bold">{analytics.studentName} — Performance Analytics</h1>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Enrolled</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{analytics.totalEnrollments}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Completed</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{analytics.completedCourses}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Avg Progress</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.averageProgress.toFixed(1)}%</div>
            <Progress value={analytics.averageProgress} className="h-1.5 mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Avg Score</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics.averageScore != null ? analytics.averageScore.toFixed(1) : "—"}
            </div>
            <p className="text-xs text-muted-foreground">{analytics.gradedSubmissions} graded</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Assignment Scores</CardTitle></CardHeader>
          <CardContent>
            {scoreData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No graded submissions.</p>
            ) : (
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={scoreData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis domain={[0, 100]} tickFormatter={v => `${v}%`} />
                    <Tooltip formatter={(v) => [`${v}%`, "Score"]} />
                    <Bar dataKey="pct" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Course Progress</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {analytics.recentEnrollments?.map(e => (
              <div key={e.id} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium truncate">{e.courseTitle}</span>
                  <span className="text-muted-foreground shrink-0 ml-2">{e.progressPercentage?.toFixed(0)}%</span>
                </div>
                <Progress value={e.progressPercentage} className="h-1.5" />
                <Badge variant={e.status === "COMPLETED" ? "default" : "secondary"} className="text-xs">{e.status}</Badge>
              </div>
            ))}
            {(!analytics.recentEnrollments || analytics.recentEnrollments.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">No enrollments.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
