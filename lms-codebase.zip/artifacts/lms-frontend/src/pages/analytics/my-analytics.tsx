import { useGetMyAnalytics } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts";
import { TrendingUp, BookOpen, CheckCircle, Star } from "lucide-react";

export default function MyAnalytics() {
  const { data: analytics, isLoading } = useGetMyAnalytics();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">My Analytics</h1>
        <div className="grid gap-4 md:grid-cols-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    );
  }

  if (!analytics) return <div className="text-destructive">Failed to load analytics</div>;

  const scoreData = analytics.recentSubmissions
    ?.filter(s => s.status === "GRADED" && s.score != null)
    .map(s => ({
      name: s.assignmentTitle?.slice(0, 12) + "…" || "Assignment",
      pct: s.maxScore ? Math.round(((s.score!) / s.maxScore) * 100) : 0,
    })) ?? [];

  const progressData = analytics.recentEnrollments?.map(e => ({
    name: e.courseTitle?.slice(0, 14) + "…" || "Course",
    progress: e.progressPercentage ?? 0,
  })) ?? [];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">My Performance Analytics</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Enrolled Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.totalEnrollments}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.completedCourses}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg. Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.averageProgress.toFixed(1)}%</div>
            <Progress value={analytics.averageProgress} className="h-1.5 mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg. Score</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics.averageScore != null ? analytics.averageScore.toFixed(1) : "—"}
            </div>
            <p className="text-xs text-muted-foreground">{analytics.gradedSubmissions} graded</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Assignment Scores</CardTitle>
            <CardDescription>Your recent graded assignments</CardDescription>
          </CardHeader>
          <CardContent>
            {scoreData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No graded assignments yet.</p>
            ) : (
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={scoreData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis domain={[0, 100]} tickFormatter={v => `${v}%`} />
                    <Tooltip formatter={(v) => [`${v}%`, "Score"]} />
                    <Bar dataKey="pct" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Course Progress</CardTitle>
            <CardDescription>Progress across enrolled courses</CardDescription>
          </CardHeader>
          <CardContent>
            {progressData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No enrollments yet.</p>
            ) : (
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={progressData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <Radar dataKey="progress" fill="#22d3ee" fillOpacity={0.5} stroke="#22d3ee" />
                    <Tooltip formatter={(v) => [`${v}%`, "Progress"]} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Recent Enrollments</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {analytics.recentEnrollments?.map(e => (
              <div key={e.id} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <Link href={`/courses/${e.courseId}`} className="font-medium hover:underline">
                    {e.courseTitle}
                  </Link>
                  <span className="text-muted-foreground">{e.progressPercentage?.toFixed(0)}%</span>
                </div>
                <Progress value={e.progressPercentage} className="h-1.5" />
                <div className="flex items-center justify-between">
                  <Badge variant={e.status === "COMPLETED" ? "default" : "secondary"} className="text-xs">{e.status}</Badge>
                  {e.enrolledAt && <span className="text-xs text-muted-foreground">{new Date(e.enrolledAt).toLocaleDateString()}</span>}
                </div>
              </div>
            ))}
            {(!analytics.recentEnrollments || analytics.recentEnrollments.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">No enrollments yet.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Recent Submissions</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {analytics.recentSubmissions?.map(s => (
              <div key={s.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">{s.assignmentTitle}</p>
                  <p className="text-xs text-muted-foreground">
                    {s.submittedAt ? new Date(s.submittedAt).toLocaleDateString() : ""}
                  </p>
                </div>
                <div className="text-right">
                  <Badge variant={s.status === "GRADED" ? "default" : "secondary"}>{s.status}</Badge>
                  {s.status === "GRADED" && s.maxScore && (
                    <p className="text-xs text-muted-foreground mt-1">{s.score}/{s.maxScore}</p>
                  )}
                </div>
              </div>
            ))}
            {(!analytics.recentSubmissions || analytics.recentSubmissions.length === 0) && (
              <p className="text-sm text-muted-foreground text-center py-4">No submissions yet.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
