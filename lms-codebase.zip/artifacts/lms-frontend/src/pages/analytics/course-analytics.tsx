import { useRoute, Link } from "wouter";
import { useGetCourseAnalytics, useGetCourseById } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { ChevronLeft } from "lucide-react";

const COLORS = ["#6366f1", "#22d3ee", "#f59e0b"];

export default function CourseAnalytics() {
  const [, params] = useRoute("/analytics/courses/:id");
  const id = Number(params?.id);

  const { data: analytics, isLoading } = useGetCourseAnalytics({ params: { id } });
  const { data: course } = useGetCourseById({ params: { id } });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-4 md:grid-cols-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!analytics) return <div className="text-destructive">Course not found</div>;

  const statusData = [
    { name: "Completed", value: analytics.completedEnrollments ?? 0 },
    { name: "Active", value: (analytics.totalEnrollments - (analytics.completedEnrollments ?? 0)) },
  ].filter(d => d.value > 0);

  const submissionData = [
    { name: "Assignments", value: analytics.totalAssignments ?? 0 },
    { name: "Submissions", value: analytics.totalSubmissions ?? 0 },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/analytics/overview"><ChevronLeft className="h-4 w-4 mr-1" />Back</Link>
        </Button>
      </div>

      <div>
        <h1 className="text-2xl font-bold">{analytics.courseTitle}</h1>
        {course?.category && <p className="text-muted-foreground">{course.category}</p>}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Enrollments</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{analytics.totalEnrollments}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Completions</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.completedEnrollments ?? 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Completion Rate</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.completionRate.toFixed(1)}%</div>
            <Progress value={analytics.completionRate} className="h-1.5 mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Avg Score</CardTitle></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics.averageScore != null ? analytics.averageScore.toFixed(1) : "—"}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Enrollment Status</CardTitle></CardHeader>
          <CardContent>
            {statusData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No enrollments yet.</p>
            ) : (
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                      {statusData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Assignments vs Submissions</CardTitle></CardHeader>
          <CardContent>
            <div className="h-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={submissionData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
