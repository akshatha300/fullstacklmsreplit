import { useGetMyEnrollments, useGetMySubmissions, useGetMyAnalytics } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { BookOpen, CheckCircle, Clock, TrendingUp } from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

export default function StudentDashboard() {
  const { data: enrollments, isLoading: loadingEnrollments } = useGetMyEnrollments();
  const { data: submissions, isLoading: loadingSubmissions } = useGetMySubmissions();
  const { data: analytics, isLoading: loadingAnalytics } = useGetMyAnalytics();

  const isLoading = loadingEnrollments || loadingSubmissions || loadingAnalytics;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">My Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    );
  }

  const activeEnrollments = enrollments?.filter(e => e.status === "ACTIVE") ?? [];
  const completedCourses = enrollments?.filter(e => e.status === "COMPLETED") ?? [];
  const pendingSubmissions = submissions?.filter(s => s.status === "SUBMITTED") ?? [];
  const gradedSubmissions = submissions?.filter(s => s.status === "GRADED") ?? [];

  const scoreData = gradedSubmissions.map(s => ({
    name: s.assignmentTitle?.slice(0, 15) + "..." || "Assignment",
    score: s.score ?? 0,
    max: s.maxScore ?? 100,
    pct: s.maxScore ? Math.round(((s.score ?? 0) / s.maxScore) * 100) : 0,
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">My Dashboard</h1>
        <Button asChild>
          <Link href="/courses">Browse Courses</Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeEnrollments.length}</div>
            <p className="text-xs text-muted-foreground">Currently enrolled</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedCourses.length}</div>
            <p className="text-xs text-muted-foreground">Courses finished</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.averageProgress?.toFixed(1) ?? 0}%</div>
            <p className="text-xs text-muted-foreground">Across all courses</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Score</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics?.averageScore != null ? analytics.averageScore.toFixed(1) : "—"}
            </div>
            <p className="text-xs text-muted-foreground">
              {analytics?.gradedSubmissions ?? 0} graded submissions
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>My Courses</CardTitle>
            <CardDescription>Your enrollment progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeEnrollments.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">
                No active enrollments. <Link href="/courses" className="text-primary hover:underline">Browse courses</Link>
              </p>
            ) : (
              activeEnrollments.map(e => (
                <div key={e.id} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <Link href={`/courses/${e.courseId}`} className="font-medium hover:underline truncate max-w-[200px]">
                      {e.courseTitle}
                    </Link>
                    <span className="text-muted-foreground ml-2 shrink-0">{e.progressPercentage?.toFixed(0)}%</span>
                  </div>
                  <Progress value={e.progressPercentage} className="h-2" />
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Scores</CardTitle>
            <CardDescription>Your assignment performance</CardDescription>
          </CardHeader>
          <CardContent>
            {scoreData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">No graded submissions yet</p>
            ) : (
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={scoreData.slice(-6)}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis domain={[0, 100]} tickFormatter={v => `${v}%`} />
                    <Tooltip formatter={(v) => [`${v}%`, "Score"]} />
                    <Bar dataKey="pct" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pending Submissions</CardTitle>
          <CardDescription>Assignments awaiting your submission</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingSubmissions.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No pending submissions</p>
          ) : (
            <div className="space-y-2">
              {pendingSubmissions.map(s => (
                <div key={s.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium text-sm">{s.assignmentTitle}</p>
                    <p className="text-xs text-muted-foreground">Submitted — awaiting grade</p>
                  </div>
                  <Badge variant="secondary">Submitted</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
