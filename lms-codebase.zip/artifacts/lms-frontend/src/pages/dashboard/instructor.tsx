import { useGetMyCourses, useGetMyAnalytics } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { BookOpen, Users, PlusCircle, BarChart2 } from "lucide-react";

export default function InstructorDashboard() {
  const { data: courses, isLoading } = useGetMyCourses();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Instructor Dashboard</h1>
        <div className="grid gap-4 md:grid-cols-3">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  const published = courses?.filter(c => c.status === "PUBLISHED") ?? [];
  const drafts = courses?.filter(c => c.status === "DRAFT") ?? [];
  const totalStudents = courses?.reduce((sum, c) => sum + (c.enrollmentCount ?? 0), 0) ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Instructor Dashboard</h1>
        <Button asChild>
          <Link href="/courses/create">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Course
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Courses</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{courses?.length ?? 0}</div>
            <p className="text-xs text-muted-foreground">{published.length} published, {drafts.length} draft</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStudents}</div>
            <p className="text-xs text-muted-foreground">Across all courses</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Published Courses</CardTitle>
            <BarChart2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{published.length}</div>
            <p className="text-xs text-muted-foreground">Live to students</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>My Courses</CardTitle>
          <CardDescription>Manage your course catalog</CardDescription>
        </CardHeader>
        <CardContent>
          {courses?.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground mb-4">You haven't created any courses yet.</p>
              <Button asChild>
                <Link href="/courses/create">Create your first course</Link>
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {courses?.map(course => (
                <div key={course.id} className="flex items-center justify-between py-4">
                  <div className="space-y-1">
                    <p className="font-medium">{course.title}</p>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <span>{course.category || "Uncategorized"}</span>
                      <span>•</span>
                      <span>{course.enrollmentCount ?? 0} students</span>
                      {course.moduleCount != null && (
                        <>
                          <span>•</span>
                          <span>{course.moduleCount} modules</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={course.status === "PUBLISHED" ? "default" : course.status === "DRAFT" ? "secondary" : "outline"}>
                      {course.status}
                    </Badge>
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/courses/${course.id}/manage`}>Manage</Link>
                    </Button>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/analytics/courses/${course.id}`}>Analytics</Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
