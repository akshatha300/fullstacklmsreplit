import { useRoute, Link } from "wouter";
import { useGetCourseById, useGetCourseModules, useGetCourseAssignments, useEnrollInCourse, useGetMyEnrollments, useUpdateProgress } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, Users, ChevronLeft, Clock, FileText } from "lucide-react";

export default function CourseDetail() {
  const [, params] = useRoute("/courses/:id");
  const courseId = Number(params?.id);
  const { role } = useAuth();
  const { toast } = useToast();

  const { data: course, isLoading } = useGetCourseById({ params: { id: courseId } });
  const { data: modules } = useGetCourseModules({ params: { courseId } });
  const { data: assignments } = useGetCourseAssignments({ params: { courseId } });
  const { data: enrollments } = useGetMyEnrollments();
  const enrollMutation = useEnrollInCourse();
  const progressMutation = useUpdateProgress();

  const myEnrollment = enrollments?.find(e => e.courseId === courseId);
  const isEnrolled = !!myEnrollment;

  const handleEnroll = () => {
    enrollMutation.mutate(
      { params: { courseId } },
      {
        onSuccess: () => toast({ title: "Enrolled successfully!" }),
        onError: () => toast({ title: "Enrollment failed", variant: "destructive" }),
      }
    );
  };

  const handleProgress = (pct: number) => {
    if (!myEnrollment) return;
    progressMutation.mutate(
      { params: { enrollmentId: myEnrollment.id }, data: { progressPercentage: pct } },
      { onSuccess: () => toast({ title: "Progress updated" }) }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 rounded-xl" />
        <Skeleton className="h-48 rounded-xl" />
      </div>
    );
  }

  if (!course) return <div className="text-destructive">Course not found</div>;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/courses"><ChevronLeft className="h-4 w-4 mr-1" />Back to Catalog</Link>
        </Button>
      </div>

      <div className="space-y-4">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              {course.category && <Badge variant="outline">{course.category}</Badge>}
              <Badge variant={course.status === "PUBLISHED" ? "default" : "secondary"}>{course.status}</Badge>
            </div>
            <h1 className="text-3xl font-bold tracking-tight">{course.title}</h1>
            <p className="text-muted-foreground">{course.description}</p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><Users className="h-4 w-4" />{course.enrollmentCount ?? 0} students</span>
              <span>by {course.instructorName}</span>
              {course.moduleCount != null && (
                <span className="flex items-center gap-1"><BookOpen className="h-4 w-4" />{course.moduleCount} modules</span>
              )}
            </div>
          </div>
          <div className="flex flex-col gap-2">
            {role === "STUDENT" && (
              isEnrolled ? (
                <div className="space-y-2 min-w-[200px]">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Your progress</span>
                    <span>{myEnrollment.progressPercentage?.toFixed(0)}%</span>
                  </div>
                  <Progress value={myEnrollment.progressPercentage} />
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleProgress(Math.min(100, (myEnrollment.progressPercentage ?? 0) + 10))}>
                      +10%
                    </Button>
                    <Button size="sm" onClick={() => handleProgress(100)}>Mark Complete</Button>
                  </div>
                </div>
              ) : (
                <Button onClick={handleEnroll} disabled={enrollMutation.isPending}>
                  {enrollMutation.isPending ? "Enrolling..." : "Enroll Now"}
                </Button>
              )
            )}
            {role === "INSTRUCTOR" && course.instructorId && (
              <Button variant="outline" asChild>
                <Link href={`/courses/${courseId}/manage`}>Manage Course</Link>
              </Button>
            )}
            {role === "ADMIN" && (
              <Button variant="outline" asChild>
                <Link href={`/analytics/courses/${courseId}`}>View Analytics</Link>
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Course Content</CardTitle>
              <CardDescription>{modules?.length ?? 0} modules</CardDescription>
            </CardHeader>
            <CardContent>
              {modules?.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">No modules yet.</p>
              ) : (
                <Accordion type="multiple" className="w-full">
                  {modules?.map((mod, idx) => (
                    <AccordionItem key={mod.id} value={String(mod.id)}>
                      <AccordionTrigger>
                        <span className="font-medium">Module {idx + 1}: {mod.title}</span>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 pl-4">
                          {mod.description && <p className="text-sm text-muted-foreground mb-3">{mod.description}</p>}
                          {mod.lessons?.map(lesson => (
                            <div key={lesson.id} className="flex items-center gap-2 text-sm py-1">
                              <Clock className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                              <span>{lesson.title}</span>
                              <Badge variant="outline" className="ml-auto text-xs">{lesson.type}</Badge>
                              {lesson.durationMinutes && (
                                <span className="text-muted-foreground">{lesson.durationMinutes}m</span>
                              )}
                            </div>
                          ))}
                          {(!mod.lessons || mod.lessons.length === 0) && (
                            <p className="text-sm text-muted-foreground">No lessons added yet.</p>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="h-4 w-4" /> Assignments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {assignments?.length === 0 ? (
                <p className="text-sm text-muted-foreground">No assignments yet.</p>
              ) : (
                assignments?.map(a => (
                  <div key={a.id} className="border rounded-lg p-3 space-y-1">
                    <p className="font-medium text-sm">{a.title}</p>
                    {a.description && <p className="text-xs text-muted-foreground line-clamp-2">{a.description}</p>}
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Max: {a.maxScore} pts</span>
                      {a.dueDate && <span>Due: {new Date(a.dueDate).toLocaleDateString()}</span>}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
