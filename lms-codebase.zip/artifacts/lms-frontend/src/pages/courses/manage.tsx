import { useState } from "react";
import { useRoute, Link } from "wouter";
import {
  useGetCourseById,
  useGetCourseModules,
  useGetCourseAssignments,
  useGetAssignmentSubmissions,
  useUpdateCourse,
  useAddModule,
  useCreateAssignment,
  useGradeSubmission,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ChevronLeft, PlusCircle } from "lucide-react";

function GradeDialog({ submissionId, maxScore }: { submissionId: number; maxScore: number }) {
  const [score, setScore] = useState("");
  const [feedback, setFeedback] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const gradeMutation = useGradeSubmission();

  const handleGrade = () => {
    gradeMutation.mutate(
      { params: { id: submissionId }, data: { score: Number(score), feedback } },
      {
        onSuccess: () => { toast({ title: "Graded!" }); setOpen(false); },
        onError: () => toast({ title: "Failed to grade", variant: "destructive" }),
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">Grade</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Grade Submission</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Score (max {maxScore})</Label>
            <Input type="number" min={0} max={maxScore} value={score} onChange={e => setScore(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Feedback (optional)</Label>
            <Textarea value={feedback} onChange={e => setFeedback(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleGrade} disabled={!score || gradeMutation.isPending}>
            {gradeMutation.isPending ? "Saving..." : "Save Grade"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AssignmentSubmissions({ assignmentId, maxScore }: { assignmentId: number; maxScore: number }) {
  const { data: submissions } = useGetAssignmentSubmissions({ params: { assignmentId } });

  return (
    <div className="space-y-2 pl-4 mt-2">
      {submissions?.length === 0 && <p className="text-sm text-muted-foreground">No submissions yet.</p>}
      {submissions?.map(s => (
        <div key={s.id} className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
          <div className="space-y-0.5">
            <p className="text-sm font-medium">{s.studentName}</p>
            <p className="text-xs text-muted-foreground">
              {s.submittedAt ? new Date(s.submittedAt).toLocaleString() : "Not submitted"}
            </p>
            {s.content && <p className="text-xs text-muted-foreground truncate max-w-xs">{s.content}</p>}
          </div>
          <div className="flex items-center gap-2">
            {s.status === "GRADED" ? (
              <div className="text-right">
                <p className="text-sm font-medium">{s.score}/{maxScore}</p>
                <Badge variant="outline" className="text-xs">Graded</Badge>
              </div>
            ) : (
              <GradeDialog submissionId={s.id} maxScore={maxScore} />
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function ManageCourse() {
  const [, params] = useRoute("/courses/:id/manage");
  const courseId = Number(params?.id);
  const { toast } = useToast();

  const { data: course, isLoading } = useGetCourseById({ params: { id: courseId } });
  const { data: modules, refetch: refetchModules } = useGetCourseModules({ params: { courseId } });
  const { data: assignments, refetch: refetchAssignments } = useGetCourseAssignments({ params: { courseId } });

  const updateMutation = useUpdateCourse();
  const addModuleMutation = useAddModule();
  const createAssignmentMutation = useCreateAssignment();

  const [newModuleTitle, setNewModuleTitle] = useState("");
  const [newModuleDesc, setNewModuleDesc] = useState("");
  const [moduleOpen, setModuleOpen] = useState(false);

  const [newAssTitle, setNewAssTitle] = useState("");
  const [newAssDesc, setNewAssDesc] = useState("");
  const [newAssMax, setNewAssMax] = useState("100");
  const [newAssDue, setNewAssDue] = useState("");
  const [assOpen, setAssOpen] = useState(false);

  const [expandedAss, setExpandedAss] = useState<number | null>(null);

  const handleStatusChange = (status: string) => {
    updateMutation.mutate(
      { params: { id: courseId }, data: { title: course!.title, status: status as any } },
      {
        onSuccess: () => toast({ title: `Course ${status.toLowerCase()}` }),
        onError: () => toast({ title: "Update failed", variant: "destructive" }),
      }
    );
  };

  const handleAddModule = () => {
    addModuleMutation.mutate(
      { params: { courseId }, data: { title: newModuleTitle, description: newModuleDesc } },
      {
        onSuccess: () => {
          toast({ title: "Module added" });
          setNewModuleTitle(""); setNewModuleDesc(""); setModuleOpen(false);
          refetchModules();
        },
        onError: () => toast({ title: "Failed to add module", variant: "destructive" }),
      }
    );
  };

  const handleAddAssignment = () => {
    createAssignmentMutation.mutate(
      {
        params: { courseId },
        data: {
          title: newAssTitle,
          description: newAssDesc,
          maxScore: Number(newAssMax),
          dueDate: newAssDue ? new Date(newAssDue).toISOString() : undefined,
        }
      },
      {
        onSuccess: () => {
          toast({ title: "Assignment created" });
          setNewAssTitle(""); setNewAssDesc(""); setNewAssMax("100"); setNewAssDue(""); setAssOpen(false);
          refetchAssignments();
        },
        onError: () => toast({ title: "Failed to create assignment", variant: "destructive" }),
      }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  if (!course) return <div className="text-destructive">Course not found</div>;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/dashboard/instructor"><ChevronLeft className="h-4 w-4 mr-1" />Back</Link>
        </Button>
      </div>

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">{course.title}</h1>
          <p className="text-muted-foreground text-sm">{course.category}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={course.status === "PUBLISHED" ? "default" : "secondary"}>{course.status}</Badge>
          <Select value={course.status} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="PUBLISHED">Published</SelectItem>
              <SelectItem value="ARCHIVED">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="modules">
        <TabsList>
          <TabsTrigger value="modules">Modules ({modules?.length ?? 0})</TabsTrigger>
          <TabsTrigger value="assignments">Assignments ({assignments?.length ?? 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="modules" className="space-y-4 mt-4">
          <div className="flex justify-end">
            <Dialog open={moduleOpen} onOpenChange={setModuleOpen}>
              <DialogTrigger asChild>
                <Button><PlusCircle className="h-4 w-4 mr-2" />Add Module</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>New Module</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title *</Label>
                    <Input value={newModuleTitle} onChange={e => setNewModuleTitle(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea value={newModuleDesc} onChange={e => setNewModuleDesc(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddModule} disabled={!newModuleTitle || addModuleMutation.isPending}>
                    {addModuleMutation.isPending ? "Adding..." : "Add Module"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            {modules?.length === 0 && (
              <Card className="border-dashed">
                <CardContent className="text-center py-10 text-muted-foreground">
                  No modules yet. Add your first module to get started.
                </CardContent>
              </Card>
            )}
            {modules?.map((mod, idx) => (
              <Card key={mod.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Module {idx + 1}: {mod.title}</CardTitle>
                  {mod.description && <p className="text-sm text-muted-foreground">{mod.description}</p>}
                </CardHeader>
                {mod.lessons && mod.lessons.length > 0 && (
                  <CardContent className="pt-0">
                    <div className="space-y-1">
                      {mod.lessons.map(l => (
                        <div key={l.id} className="flex items-center gap-2 text-sm py-1 pl-2 border-l-2 border-muted">
                          <span className="flex-1">{l.title}</span>
                          <Badge variant="outline" className="text-xs">{l.type}</Badge>
                          {l.durationMinutes && <span className="text-muted-foreground text-xs">{l.durationMinutes}m</span>}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="assignments" className="space-y-4 mt-4">
          <div className="flex justify-end">
            <Dialog open={assOpen} onOpenChange={setAssOpen}>
              <DialogTrigger asChild>
                <Button><PlusCircle className="h-4 w-4 mr-2" />Create Assignment</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>New Assignment</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title *</Label>
                    <Input value={newAssTitle} onChange={e => setNewAssTitle(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea value={newAssDesc} onChange={e => setNewAssDesc(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Max Score *</Label>
                    <Input type="number" value={newAssMax} onChange={e => setNewAssMax(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Due Date</Label>
                    <Input type="datetime-local" value={newAssDue} onChange={e => setNewAssDue(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddAssignment} disabled={!newAssTitle || createAssignmentMutation.isPending}>
                    {createAssignmentMutation.isPending ? "Creating..." : "Create"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            {assignments?.length === 0 && (
              <Card className="border-dashed">
                <CardContent className="text-center py-10 text-muted-foreground">
                  No assignments yet.
                </CardContent>
              </Card>
            )}
            {assignments?.map(a => (
              <Card key={a.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{a.title}</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedAss(expandedAss === a.id ? null : a.id)}
                    >
                      {expandedAss === a.id ? "Hide" : `Submissions (${a.submissionCount ?? 0})`}
                    </Button>
                  </div>
                  <div className="flex gap-3 text-sm text-muted-foreground">
                    <span>Max: {a.maxScore} pts</span>
                    {a.dueDate && <span>Due: {new Date(a.dueDate).toLocaleDateString()}</span>}
                  </div>
                </CardHeader>
                {expandedAss === a.id && (
                  <CardContent className="pt-0">
                    <AssignmentSubmissions assignmentId={a.id} maxScore={a.maxScore} />
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
