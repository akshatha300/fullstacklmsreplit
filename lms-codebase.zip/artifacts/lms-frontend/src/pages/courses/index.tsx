import { useState } from "react";
import { useGetCourses, useEnrollInCourse, useGetMyEnrollments } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, Search, Users } from "lucide-react";

export default function CourseCatalog() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const { role } = useAuth();
  const { toast } = useToast();

  const { data: courses, isLoading } = useGetCourses({ search: search || undefined, category: category || undefined });
  const { data: enrollments } = useGetMyEnrollments();
  const enrollMutation = useEnrollInCourse();

  const enrolledCourseIds = new Set(enrollments?.map(e => e.courseId) ?? []);

  const handleEnroll = (courseId: number) => {
    enrollMutation.mutate(
      { params: { courseId } },
      {
        onSuccess: () => toast({ title: "Enrolled successfully!" }),
        onError: () => toast({ title: "Enrollment failed", variant: "destructive" }),
      }
    );
  };

  const categories = [...new Set(courses?.map(c => c.category).filter(Boolean))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Course Catalog</h1>
          <p className="text-muted-foreground">Discover and enroll in courses</p>
        </div>
        {role === "INSTRUCTOR" && (
          <Button asChild>
            <Link href="/courses/create">Create Course</Link>
          </Button>
        )}
        {role === "ADMIN" && (
          <Button asChild>
            <Link href="/courses/all">Manage All</Link>
          </Button>
        )}
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search courses..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={category === "" ? "default" : "outline"}
            size="sm"
            onClick={() => setCategory("")}
          >
            All
          </Button>
          {categories.map(cat => (
            <Button
              key={cat}
              variant={category === cat ? "default" : "outline"}
              size="sm"
              onClick={() => setCategory(cat === category ? "" : cat!)}
            >
              {cat}
            </Button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      ) : courses?.length === 0 ? (
        <div className="text-center py-16">
          <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <p className="text-muted-foreground">No courses found.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {courses?.map(course => {
            const isEnrolled = enrolledCourseIds.has(course.id);
            return (
              <Card key={course.id} className="flex flex-col hover:shadow-md transition-shadow">
                {course.thumbnailUrl ? (
                  <img src={course.thumbnailUrl} alt={course.title} className="w-full h-40 object-cover rounded-t-xl" />
                ) : (
                  <div className="w-full h-40 bg-gradient-to-br from-primary/20 to-primary/5 rounded-t-xl flex items-center justify-center">
                    <BookOpen className="h-12 w-12 text-primary/40" />
                  </div>
                )}
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg leading-tight line-clamp-2">{course.title}</CardTitle>
                    {course.category && <Badge variant="outline" className="shrink-0">{course.category}</Badge>}
                  </div>
                  <CardDescription className="line-clamp-2">{course.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{course.enrollmentCount ?? 0} students</span>
                    <span>•</span>
                    <span>by {course.instructorName}</span>
                  </div>
                </CardContent>
                <CardFooter className="gap-2">
                  <Button variant="outline" size="sm" asChild className="flex-1">
                    <Link href={`/courses/${course.id}`}>View</Link>
                  </Button>
                  {role === "STUDENT" && (
                    <Button
                      size="sm"
                      className="flex-1"
                      disabled={isEnrolled || enrollMutation.isPending}
                      onClick={() => handleEnroll(course.id)}
                    >
                      {isEnrolled ? "Enrolled" : "Enroll"}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
