import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useCreateCourse } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ChevronLeft } from "lucide-react";

const CATEGORIES = ["Programming", "Design", "Business", "Marketing", "Data Science", "Mathematics", "Science", "Language", "Other"];

export default function CreateCourse() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createMutation = useCreateCourse();

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    thumbnailUrl: "",
    status: "DRAFT" as "DRAFT" | "PUBLISHED",
  });

  const set = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [field]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(
      { data: { ...form, thumbnailUrl: form.thumbnailUrl || undefined, description: form.description || undefined, category: form.category || undefined } },
      {
        onSuccess: (course) => {
          toast({ title: "Course created!" });
          setLocation(`/courses/${course.id}/manage`);
        },
        onError: () => toast({ title: "Failed to create course", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/dashboard/instructor"><ChevronLeft className="h-4 w-4 mr-1" />Back</Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Create New Course</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="title">Course Title *</Label>
              <Input id="title" value={form.title} onChange={set("title")} required placeholder="e.g. Introduction to Python" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" value={form.description} onChange={set("description")} rows={4} placeholder="What will students learn?" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v: any) => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="PUBLISHED">Published</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="thumbnail">Thumbnail URL</Label>
              <Input id="thumbnail" type="url" value={form.thumbnailUrl} onChange={set("thumbnailUrl")} placeholder="https://..." />
            </div>

            <div className="flex gap-3 pt-2">
              <Button type="submit" disabled={!form.title || createMutation.isPending}>
                {createMutation.isPending ? "Creating..." : "Create Course"}
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/dashboard/instructor">Cancel</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
