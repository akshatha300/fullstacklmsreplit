import { useState } from "react";
import { useGetMySubmissions, useGetMyEnrollments, useGetCourseAssignments, useSubmitAssignment } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Clock, FileText } from "lucide-react";

function SubmitDialog({ assignmentId, onSuccess }: { assignmentId: number; onSuccess: () => void }) {
  const [content, setContent] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const submitMutation = useSubmitAssignment();

  const handleSubmit = () => {
    submitMutation.mutate(
      { params: { assignmentId }, data: { content } },
      {
        onSuccess: () => {
          toast({ title: "Submitted successfully!" });
          setOpen(false);
          onSuccess();
        },
        onError: () => toast({ title: "Submission failed", variant: "destructive" }),
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">Submit</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Submit Assignment</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-2">
            <Label>Your Work</Label>
            <Textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Write your answer or paste your submission here..."
              rows={6}
            />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleSubmit} disabled={submitMutation.isPending}>
            {submitMutation.isPending ? "Submitting..." : "Submit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CourseAssignments({ courseId, submittedIds }: { courseId: number; submittedIds: Set<number> }) {
  const { data: assignments, refetch } = useGetCourseAssignments({ params: { courseId } });

  return (
    <div className="space-y-3">
      {assignments?.map(a => {
        const submitted = submittedIds.has(a.id);
        return (
          <Card key={a.id} className={submitted ? "border-green-200 bg-green-50/30" : ""}>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">{a.title}</CardTitle>
                  {a.description && <CardDescription className="mt-1">{a.description}</CardDescription>}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm text-muted-foreground">{a.maxScore} pts</span>
                  {submitted ? (
                    <Badge variant="outline" className="border-green-500 text-green-700">
                      <CheckCircle className="h-3 w-3 mr-1" /> Submitted
                    </Badge>
                  ) : (
                    <SubmitDialog assignmentId={a.id} onSuccess={() => refetch()} />
                  )}
                </div>
              </div>
            </CardHeader>
            {a.dueDate && (
              <CardContent className="pt-0">
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" /> Due: {new Date(a.dueDate).toLocaleString()}
                </p>
              </CardContent>
            )}
          </Card>
        );
      })}
      {assignments?.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-4">No assignments for this course.</p>
      )}
    </div>
  );
}

export default function AssignmentsPage() {
  const { data: submissions, isLoading: loadingSubs, refetch } = useGetMySubmissions();
  const { data: enrollments, isLoading: loadingEnr } = useGetMyEnrollments();

  const isLoading = loadingSubs || loadingEnr;

  const submittedAssignmentIds = new Set(submissions?.map(s => s.assignmentId) ?? []);
  const gradedSubs = submissions?.filter(s => s.status === "GRADED") ?? [];
  const pendingSubs = submissions?.filter(s => s.status === "SUBMITTED") ?? [];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Assignments</h1>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Submitted</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{submissions?.length ?? 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Graded</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{gradedSubs.length}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{pendingSubs.length}</div></CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending">By Course</TabsTrigger>
          <TabsTrigger value="submitted">My Submissions ({submissions?.length ?? 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-4 space-y-6">
          {isLoading && <div className="space-y-4">{[1,2].map(i => <Skeleton key={i} className="h-48 rounded-xl" />)}</div>}
          {enrollments?.filter(e => e.status === "ACTIVE").map(e => (
            <div key={e.id}>
              <h2 className="font-semibold text-lg mb-3">{e.courseTitle}</h2>
              <CourseAssignments courseId={e.courseId} submittedIds={submittedAssignmentIds} />
            </div>
          ))}
          {!isLoading && enrollments?.filter(e => e.status === "ACTIVE").length === 0 && (
            <p className="text-muted-foreground text-center py-8">No active enrollments.</p>
          )}
        </TabsContent>

        <TabsContent value="submitted" className="mt-4">
          <div className="space-y-3">
            {submissions?.length === 0 && (
              <p className="text-muted-foreground text-center py-8">No submissions yet.</p>
            )}
            {submissions?.map(s => (
              <Card key={s.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <CardTitle className="text-base">{s.assignmentTitle}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">
                        Submitted: {s.submittedAt ? new Date(s.submittedAt).toLocaleString() : "—"}
                      </p>
                    </div>
                    <Badge variant={s.status === "GRADED" ? "default" : "secondary"}>{s.status}</Badge>
                  </div>
                </CardHeader>
                {s.status === "GRADED" && (
                  <CardContent className="pt-0 space-y-1">
                    <p className="font-medium text-sm">Score: {s.score}/{s.maxScore} ({s.maxScore ? ((s.score! / s.maxScore) * 100).toFixed(0) : 0}%)</p>
                    {s.feedback && <p className="text-sm text-muted-foreground">Feedback: {s.feedback}</p>}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
