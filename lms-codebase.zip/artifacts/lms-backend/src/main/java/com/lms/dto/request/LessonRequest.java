package com.lms.dto.request;

import com.lms.entity.LessonType;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LessonRequest {
    @NotBlank
    private String title;
    private String content;
    private LessonType type;
    private Integer durationMinutes;
    private Integer orderIndex;
    private String videoUrl;
}
