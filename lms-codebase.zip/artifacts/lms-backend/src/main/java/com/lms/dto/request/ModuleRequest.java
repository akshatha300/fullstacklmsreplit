package com.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ModuleRequest {
    @NotBlank
    private String title;
    private String description;
    private Integer orderIndex;
}
