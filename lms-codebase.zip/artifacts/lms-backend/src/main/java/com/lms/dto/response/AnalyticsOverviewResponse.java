package com.lms.dto.response;

import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class AnalyticsOverviewResponse {
    private long totalStudents;
    private long totalInstructors;
    private long totalCourses;
    private long publishedCourses;
    private long totalEnrollments;
    private long completedEnrollments;
    private double completionRate;
    private Map<String, Long> coursesByCategory;
}
