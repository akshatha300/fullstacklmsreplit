package com.lms.service;

import com.lms.dto.request.AssignmentRequest;
import com.lms.dto.request.GradeRequest;
import com.lms.dto.request.SubmissionRequest;
import com.lms.dto.response.AssignmentResponse;
import com.lms.dto.response.SubmissionResponse;
import com.lms.entity.*;
import com.lms.repository.AssignmentRepository;
import com.lms.repository.SubmissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AssignmentService {

    private final AssignmentRepository assignmentRepository;
    private final SubmissionRepository submissionRepository;
    private final CourseService courseService;
    private final UserService userService;

    public List<AssignmentResponse> getCourseAssignments(Long courseId) {
        Course course = courseService.findCourseById(courseId);
        return assignmentRepository.findByCourseOrderByDueDateAsc(course)
                .stream().map(AssignmentResponse::from).toList();
    }

    public AssignmentResponse getAssignmentById(Long id) {
        return AssignmentResponse.from(findAssignmentById(id));
    }

    public AssignmentResponse createAssignment(Long courseId, AssignmentRequest request) {
        Course course = courseService.findCourseById(courseId);
        Assignment assignment = Assignment.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .maxScore(request.getMaxScore())
                .dueDate(request.getDueDate())
                .course(course)
                .build();
        return AssignmentResponse.from(assignmentRepository.save(assignment));
    }

    public AssignmentResponse updateAssignment(Long id, AssignmentRequest request) {
        Assignment assignment = findAssignmentById(id);
        if (request.getTitle() != null) assignment.setTitle(request.getTitle());
        if (request.getDescription() != null) assignment.setDescription(request.getDescription());
        if (request.getMaxScore() != null) assignment.setMaxScore(request.getMaxScore());
        if (request.getDueDate() != null) assignment.setDueDate(request.getDueDate());
        return AssignmentResponse.from(assignmentRepository.save(assignment));
    }

    public void deleteAssignment(Long id) {
        assignmentRepository.deleteById(id);
    }

    public SubmissionResponse submitAssignment(Long assignmentId, SubmissionRequest request) {
        User student = userService.getCurrentUser();
        Assignment assignment = findAssignmentById(assignmentId);
        Submission submission = submissionRepository
                .findByAssignmentAndStudent(assignment, student)
                .orElse(Submission.builder()
                        .assignment(assignment)
                        .student(student)
                        .build());
        submission.setContent(request.getContent());
        submission.setStatus(SubmissionStatus.SUBMITTED);
        return SubmissionResponse.from(submissionRepository.save(submission));
    }

    public List<SubmissionResponse> getAssignmentSubmissions(Long assignmentId) {
        Assignment assignment = findAssignmentById(assignmentId);
        return submissionRepository.findByAssignment(assignment)
                .stream().map(SubmissionResponse::from).toList();
    }

    public SubmissionResponse getSubmissionById(Long id) {
        return SubmissionResponse.from(submissionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Submission not found")));
    }

    public SubmissionResponse gradeSubmission(Long submissionId, GradeRequest request) {
        User grader = userService.getCurrentUser();
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new RuntimeException("Submission not found"));
        submission.setScore(request.getScore());
        submission.setFeedback(request.getFeedback());
        submission.setStatus(SubmissionStatus.GRADED);
        submission.setGradedAt(LocalDateTime.now());
        submission.setGradedBy(grader);
        return SubmissionResponse.from(submissionRepository.save(submission));
    }

    public List<SubmissionResponse> getMySubmissions() {
        User student = userService.getCurrentUser();
        return submissionRepository.findByStudentOrderBySubmittedAtDesc(student)
                .stream().map(SubmissionResponse::from).toList();
    }

    private Assignment findAssignmentById(Long id) {
        return assignmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Assignment not found: " + id));
    }
}
