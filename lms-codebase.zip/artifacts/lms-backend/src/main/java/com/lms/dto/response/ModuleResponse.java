package com.lms.dto.response;

import com.lms.entity.CourseModule;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ModuleResponse {
    private Long id;
    private String title;
    private String description;
    private Integer orderIndex;
    private Long courseId;
    private List<LessonResponse> lessons;

    public static ModuleResponse from(CourseModule module) {
        return ModuleResponse.builder()
                .id(module.getId())
                .title(module.getTitle())
                .description(module.getDescription())
                .orderIndex(module.getOrderIndex())
                .courseId(module.getCourse().getId())
                .lessons(module.getLessons().stream().map(LessonResponse::from).toList())
                .build();
    }
}
