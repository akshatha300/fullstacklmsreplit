package com.lms.dto.request;

import com.lms.entity.CourseStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CourseRequest {
    @NotBlank
    private String title;
    private String description;
    private String category;
    private String thumbnailUrl;
    private CourseStatus status;
}
