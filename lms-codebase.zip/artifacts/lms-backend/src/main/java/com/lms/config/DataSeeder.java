package com.lms.config;

import com.lms.entity.*;
import com.lms.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CourseRepository courseRepository;
    private final CourseModuleRepository moduleRepository;
    private final LessonRepository lessonRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final AssignmentRepository assignmentRepository;
    private final SubmissionRepository submissionRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        log.info("Seeding initial data...");

        User admin = userRepository.save(User.builder()
                .firstName("Admin").lastName("User")
                .email("admin@lms.com")
                .password(passwordEncoder.encode("admin123"))
                .role(Role.ADMIN).build());

        User instructor1 = userRepository.save(User.builder()
                .firstName("Sarah").lastName("Johnson")
                .email("sarah@lms.com")
                .password(passwordEncoder.encode("instructor123"))
                .role(Role.INSTRUCTOR).build());

        User instructor2 = userRepository.save(User.builder()
                .firstName("Michael").lastName("Chen")
                .email("michael@lms.com")
                .password(passwordEncoder.encode("instructor123"))
                .role(Role.INSTRUCTOR).build());

        User student1 = userRepository.save(User.builder()
                .firstName("Alice").lastName("Williams")
                .email("alice@lms.com")
                .password(passwordEncoder.encode("student123"))
                .role(Role.STUDENT).build());

        User student2 = userRepository.save(User.builder()
                .firstName("Bob").lastName("Martinez")
                .email("bob@lms.com")
                .password(passwordEncoder.encode("student123"))
                .role(Role.STUDENT).build());

        User student3 = userRepository.save(User.builder()
                .firstName("Emma").lastName("Davis")
                .email("emma@lms.com")
                .password(passwordEncoder.encode("student123"))
                .role(Role.STUDENT).build());

        Course javaCourse = courseRepository.save(Course.builder()
                .title("Java Programming Masterclass")
                .description("Comprehensive Java course from beginner to advanced. Learn OOP, data structures, Spring Boot and more.")
                .category("Programming")
                .thumbnailUrl("https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400")
                .status(CourseStatus.PUBLISHED)
                .instructor(instructor1).build());

        Course webCourse = courseRepository.save(Course.builder()
                .title("Full-Stack Web Development")
                .description("Learn HTML, CSS, JavaScript, React and Node.js to build modern web applications.")
                .category("Web Development")
                .thumbnailUrl("https://images.unsplash.com/photo-1547658719-da2b51169166?w=400")
                .status(CourseStatus.PUBLISHED)
                .instructor(instructor2).build());

        Course dataCourse = courseRepository.save(Course.builder()
                .title("Data Science with Python")
                .description("Master data analysis, visualization and machine learning using Python, Pandas, and scikit-learn.")
                .category("Data Science")
                .thumbnailUrl("https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400")
                .status(CourseStatus.PUBLISHED)
                .instructor(instructor1).build());

        courseRepository.save(Course.builder()
                .title("Cloud Architecture on AWS")
                .description("Design and deploy scalable cloud solutions using Amazon Web Services.")
                .category("Cloud")
                .status(CourseStatus.DRAFT)
                .instructor(instructor2).build());

        CourseModule m1 = moduleRepository.save(CourseModule.builder()
                .title("Introduction to Java").orderIndex(1).course(javaCourse).build());
        CourseModule m2 = moduleRepository.save(CourseModule.builder()
                .title("Object-Oriented Programming").orderIndex(2).course(javaCourse).build());

        lessonRepository.save(Lesson.builder().title("What is Java?").type(LessonType.TEXT)
                .content("Java is a high-level, class-based, object-oriented programming language...").orderIndex(1).module(m1).build());
        lessonRepository.save(Lesson.builder().title("Setting Up Your Environment").type(LessonType.VIDEO)
                .content("Install JDK and your IDE").durationMinutes(15).orderIndex(2).module(m1).build());
        lessonRepository.save(Lesson.builder().title("Classes and Objects").type(LessonType.TEXT)
                .content("A class is a blueprint for creating objects...").orderIndex(1).module(m2).build());

        CourseModule wm1 = moduleRepository.save(CourseModule.builder()
                .title("HTML Fundamentals").orderIndex(1).course(webCourse).build());
        lessonRepository.save(Lesson.builder().title("HTML Document Structure").type(LessonType.TEXT)
                .content("HTML provides the basic structure of sites...").orderIndex(1).module(wm1).build());

        Assignment a1 = assignmentRepository.save(Assignment.builder()
                .title("Java Basics Quiz")
                .description("Demonstrate your understanding of Java fundamentals by completing this assignment.")
                .maxScore(100.0).course(javaCourse).build());

        Assignment a2 = assignmentRepository.save(Assignment.builder()
                .title("OOP Design Exercise")
                .description("Create a class hierarchy demonstrating inheritance and polymorphism.")
                .maxScore(100.0).course(javaCourse).build());

        assignmentRepository.save(Assignment.builder()
                .title("Build a Landing Page")
                .description("Create a responsive landing page using HTML and CSS.")
                .maxScore(100.0).course(webCourse).build());

        Enrollment e1 = enrollmentRepository.save(Enrollment.builder()
                .student(student1).course(javaCourse).progressPercentage(65.0).build());
        Enrollment e2 = enrollmentRepository.save(Enrollment.builder()
                .student(student2).course(javaCourse).progressPercentage(30.0).build());
        enrollmentRepository.save(Enrollment.builder()
                .student(student1).course(webCourse).progressPercentage(80.0).build());
        enrollmentRepository.save(Enrollment.builder()
                .student(student3).course(dataCourse).progressPercentage(45.0).build());
        enrollmentRepository.save(Enrollment.builder()
                .student(student2).course(webCourse).progressPercentage(10.0).build());

        submissionRepository.save(Submission.builder()
                .assignment(a1).student(student1)
                .content("Java is a statically typed language. Here are the key concepts I learned...")
                .score(88.0).feedback("Great work! Good understanding of the fundamentals.")
                .status(SubmissionStatus.GRADED).gradedBy(instructor1).build());

        submissionRepository.save(Submission.builder()
                .assignment(a1).student(student2)
                .content("I learned about variables, data types and control flow...")
                .score(75.0).feedback("Good effort. Review inheritance topics.")
                .status(SubmissionStatus.GRADED).gradedBy(instructor1).build());

        submissionRepository.save(Submission.builder()
                .assignment(a2).student(student1)
                .content("I created an Animal hierarchy with Dog, Cat and Bird classes...")
                .status(SubmissionStatus.SUBMITTED).build());

        log.info("Seeding complete. Default credentials: admin@lms.com/admin123, sarah@lms.com/instructor123, alice@lms.com/student123");
    }
}
