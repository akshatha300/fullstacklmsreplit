package com.lms.repository;

import com.lms.entity.Course;
import com.lms.entity.CourseStatus;
import com.lms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByStatus(CourseStatus status);
    List<Course> findByInstructor(User instructor);
    List<Course> findByInstructorAndStatus(User instructor, CourseStatus status);

    @Query("SELECT c FROM Course c WHERE c.status = 'PUBLISHED' AND " +
           "(LOWER(c.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.category) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Course> searchPublished(@Param("query") String query);

    @Query("SELECT COUNT(c) FROM Course c WHERE c.status = :status")
    long countByStatus(@Param("status") CourseStatus status);

    @Query("SELECT c.category, COUNT(c) FROM Course c WHERE c.status = 'PUBLISHED' GROUP BY c.category")
    List<Object[]> countByCategory();
}
