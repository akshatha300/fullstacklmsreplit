package com.lms.service;

import com.lms.dto.request.CourseRequest;
import com.lms.dto.request.LessonRequest;
import com.lms.dto.request.ModuleRequest;
import com.lms.dto.response.CourseResponse;
import com.lms.dto.response.LessonResponse;
import com.lms.dto.response.ModuleResponse;
import com.lms.entity.*;
import com.lms.repository.CourseModuleRepository;
import com.lms.repository.CourseRepository;
import com.lms.repository.LessonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courseRepository;
    private final CourseModuleRepository moduleRepository;
    private final LessonRepository lessonRepository;
    private final UserService userService;

    public List<CourseResponse> getPublishedCourses() {
        return courseRepository.findByStatus(CourseStatus.PUBLISHED)
                .stream().map(CourseResponse::from).toList();
    }

    public List<CourseResponse> getAllCourses() {
        return courseRepository.findAll().stream().map(CourseResponse::from).toList();
    }

    public List<CourseResponse> getMyCourses() {
        User instructor = userService.getCurrentUser();
        return courseRepository.findByInstructor(instructor)
                .stream().map(CourseResponse::from).toList();
    }

    public CourseResponse getCourseById(Long id) {
        return CourseResponse.from(findCourseById(id));
    }

    public CourseResponse createCourse(CourseRequest request) {
        User instructor = userService.getCurrentUser();
        Course course = Course.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .category(request.getCategory())
                .thumbnailUrl(request.getThumbnailUrl())
                .status(request.getStatus() != null ? request.getStatus() : CourseStatus.DRAFT)
                .instructor(instructor)
                .build();
        return CourseResponse.from(courseRepository.save(course));
    }

    public CourseResponse updateCourse(Long id, CourseRequest request) {
        Course course = findCourseById(id);
        if (request.getTitle() != null) course.setTitle(request.getTitle());
        if (request.getDescription() != null) course.setDescription(request.getDescription());
        if (request.getCategory() != null) course.setCategory(request.getCategory());
        if (request.getThumbnailUrl() != null) course.setThumbnailUrl(request.getThumbnailUrl());
        if (request.getStatus() != null) course.setStatus(request.getStatus());
        return CourseResponse.from(courseRepository.save(course));
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }

    public List<ModuleResponse> getCourseModules(Long courseId) {
        Course course = findCourseById(courseId);
        return moduleRepository.findByCourseOrderByOrderIndexAsc(course)
                .stream().map(ModuleResponse::from).toList();
    }

    public ModuleResponse addModule(Long courseId, ModuleRequest request) {
        Course course = findCourseById(courseId);
        CourseModule module = CourseModule.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .orderIndex(request.getOrderIndex() != null ? request.getOrderIndex() : 0)
                .course(course)
                .build();
        return ModuleResponse.from(moduleRepository.save(module));
    }

    public ModuleResponse updateModule(Long moduleId, ModuleRequest request) {
        CourseModule module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new RuntimeException("Module not found"));
        if (request.getTitle() != null) module.setTitle(request.getTitle());
        if (request.getDescription() != null) module.setDescription(request.getDescription());
        if (request.getOrderIndex() != null) module.setOrderIndex(request.getOrderIndex());
        return ModuleResponse.from(moduleRepository.save(module));
    }

    public void deleteModule(Long moduleId) {
        moduleRepository.deleteById(moduleId);
    }

    public List<LessonResponse> getModuleLessons(Long moduleId) {
        CourseModule module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new RuntimeException("Module not found"));
        return lessonRepository.findByModuleOrderByOrderIndexAsc(module)
                .stream().map(LessonResponse::from).toList();
    }

    public LessonResponse addLesson(Long moduleId, LessonRequest request) {
        CourseModule module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new RuntimeException("Module not found"));
        Lesson lesson = Lesson.builder()
                .title(request.getTitle())
                .content(request.getContent())
                .type(request.getType() != null ? request.getType() : LessonType.TEXT)
                .durationMinutes(request.getDurationMinutes())
                .orderIndex(request.getOrderIndex() != null ? request.getOrderIndex() : 0)
                .videoUrl(request.getVideoUrl())
                .module(module)
                .build();
        return LessonResponse.from(lessonRepository.save(lesson));
    }

    public LessonResponse updateLesson(Long lessonId, LessonRequest request) {
        Lesson lesson = lessonRepository.findById(lessonId)
                .orElseThrow(() -> new RuntimeException("Lesson not found"));
        if (request.getTitle() != null) lesson.setTitle(request.getTitle());
        if (request.getContent() != null) lesson.setContent(request.getContent());
        if (request.getType() != null) lesson.setType(request.getType());
        if (request.getDurationMinutes() != null) lesson.setDurationMinutes(request.getDurationMinutes());
        if (request.getOrderIndex() != null) lesson.setOrderIndex(request.getOrderIndex());
        if (request.getVideoUrl() != null) lesson.setVideoUrl(request.getVideoUrl());
        return LessonResponse.from(lessonRepository.save(lesson));
    }

    public void deleteLesson(Long lessonId) {
        lessonRepository.deleteById(lessonId);
    }

    public List<CourseResponse> searchCourses(String query) {
        return courseRepository.searchPublished(query)
                .stream().map(CourseResponse::from).toList();
    }

    public Course findCourseById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found: " + id));
    }
}
