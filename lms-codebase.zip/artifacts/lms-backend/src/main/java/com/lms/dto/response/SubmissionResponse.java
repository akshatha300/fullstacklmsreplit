package com.lms.dto.response;

import com.lms.entity.Submission;
import com.lms.entity.SubmissionStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class SubmissionResponse {
    private Long id;
    private Long assignmentId;
    private String assignmentTitle;
    private Long studentId;
    private String studentName;
    private String content;
    private LocalDateTime submittedAt;
    private Double score;
    private Double maxScore;
    private String feedback;
    private SubmissionStatus status;
    private LocalDateTime gradedAt;

    public static SubmissionResponse from(Submission s) {
        return SubmissionResponse.builder()
                .id(s.getId())
                .assignmentId(s.getAssignment().getId())
                .assignmentTitle(s.getAssignment().getTitle())
                .studentId(s.getStudent().getId())
                .studentName(s.getStudent().getFirstName() + " " + s.getStudent().getLastName())
                .content(s.getContent())
                .submittedAt(s.getSubmittedAt())
                .score(s.getScore())
                .maxScore(s.getAssignment().getMaxScore())
                .feedback(s.getFeedback())
                .status(s.getStatus())
                .gradedAt(s.getGradedAt())
                .build();
    }
}
