package com.lms.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseAnalyticsResponse {
    private Long courseId;
    private String courseTitle;
    private long totalEnrollments;
    private long completedEnrollments;
    private double completionRate;
    private Double averageScore;
    private int totalAssignments;
    private long totalSubmissions;
}
