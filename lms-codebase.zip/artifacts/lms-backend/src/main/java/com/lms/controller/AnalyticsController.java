package com.lms.controller;

import com.lms.dto.response.AnalyticsOverviewResponse;
import com.lms.dto.response.CourseAnalyticsResponse;
import com.lms.dto.response.StudentAnalyticsResponse;
import com.lms.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/analytics")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/overview")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AnalyticsOverviewResponse> getOverview() {
        return ResponseEntity.ok(analyticsService.getOverview());
    }

    @GetMapping("/students/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
    public ResponseEntity<StudentAnalyticsResponse> getStudentAnalytics(@PathVariable Long id) {
        return ResponseEntity.ok(analyticsService.getStudentAnalytics(id));
    }

    @GetMapping("/my")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<StudentAnalyticsResponse> getMyAnalytics() {
        return ResponseEntity.ok(analyticsService.getMyAnalytics());
    }

    @GetMapping("/courses/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'INSTRUCTOR')")
    public ResponseEntity<CourseAnalyticsResponse> getCourseAnalytics(@PathVariable Long id) {
        return ResponseEntity.ok(analyticsService.getCourseAnalytics(id));
    }
}
