package com.lms.dto.response;

import com.lms.entity.Assignment;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class AssignmentResponse {
    private Long id;
    private String title;
    private String description;
    private Double maxScore;
    private LocalDateTime dueDate;
    private Long courseId;
    private String courseTitle;
    private int submissionCount;
    private LocalDateTime createdAt;

    public static AssignmentResponse from(Assignment a) {
        return AssignmentResponse.builder()
                .id(a.getId())
                .title(a.getTitle())
                .description(a.getDescription())
                .maxScore(a.getMaxScore())
                .dueDate(a.getDueDate())
                .courseId(a.getCourse().getId())
                .courseTitle(a.getCourse().getTitle())
                .submissionCount(a.getSubmissions().size())
                .createdAt(a.getCreatedAt())
                .build();
    }
}
