package com.lms.repository;

import com.lms.entity.Course;
import com.lms.entity.Enrollment;
import com.lms.entity.EnrollmentStatus;
import com.lms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudent(User student);
    List<Enrollment> findByCourse(Course course);
    Optional<Enrollment> findByStudentAndCourse(User student, Course course);
    boolean existsByStudentAndCourse(User student, Course course);

    @Query("SELECT e FROM Enrollment e WHERE e.student = :student AND e.status = :status")
    List<Enrollment> findByStudentAndStatus(@Param("student") User student, @Param("status") EnrollmentStatus status);

    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.course = :course")
    long countByCourse(@Param("course") Course course);

    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.status = 'COMPLETED'")
    long countCompleted();

    @Query("SELECT AVG(e.progressPercentage) FROM Enrollment e WHERE e.student = :student")
    Double avgProgressByStudent(@Param("student") User student);

    @Query("SELECT COUNT(e) FROM Enrollment e WHERE e.course.instructor = :instructor")
    long countByInstructor(@Param("instructor") User instructor);
}
