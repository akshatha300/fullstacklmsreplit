package com.lms.dto.response;

import com.lms.entity.Lesson;
import com.lms.entity.LessonType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LessonResponse {
    private Long id;
    private String title;
    private String content;
    private LessonType type;
    private Integer durationMinutes;
    private Integer orderIndex;
    private String videoUrl;
    private Long moduleId;

    public static LessonResponse from(Lesson lesson) {
        return LessonResponse.builder()
                .id(lesson.getId())
                .title(lesson.getTitle())
                .content(lesson.getContent())
                .type(lesson.getType())
                .durationMinutes(lesson.getDurationMinutes())
                .orderIndex(lesson.getOrderIndex())
                .videoUrl(lesson.getVideoUrl())
                .moduleId(lesson.getModule().getId())
                .build();
    }
}
