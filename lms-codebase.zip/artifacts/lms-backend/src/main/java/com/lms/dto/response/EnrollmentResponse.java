package com.lms.dto.response;

import com.lms.entity.Enrollment;
import com.lms.entity.EnrollmentStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class EnrollmentResponse {
    private Long id;
    private Long studentId;
    private String studentName;
    private Long courseId;
    private String courseTitle;
    private LocalDateTime enrolledAt;
    private LocalDateTime completedAt;
    private Double progressPercentage;
    private EnrollmentStatus status;

    public static EnrollmentResponse from(Enrollment e) {
        return EnrollmentResponse.builder()
                .id(e.getId())
                .studentId(e.getStudent().getId())
                .studentName(e.getStudent().getFirstName() + " " + e.getStudent().getLastName())
                .courseId(e.getCourse().getId())
                .courseTitle(e.getCourse().getTitle())
                .enrolledAt(e.getEnrolledAt())
                .completedAt(e.getCompletedAt())
                .progressPercentage(e.getProgressPercentage())
                .status(e.getStatus())
                .build();
    }
}
