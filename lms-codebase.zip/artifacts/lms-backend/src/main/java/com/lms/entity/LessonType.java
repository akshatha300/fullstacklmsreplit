package com.lms.entity;

public enum LessonType {
    VIDEO,
    TEXT,
    QUIZ
}
