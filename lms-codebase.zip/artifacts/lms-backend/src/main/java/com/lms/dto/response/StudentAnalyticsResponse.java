package com.lms.dto.response;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class StudentAnalyticsResponse {
    private Long studentId;
    private String studentName;
    private int totalEnrollments;
    private int completedCourses;
    private double averageProgress;
    private Double averageScore;
    private long gradedSubmissions;
    private List<EnrollmentResponse> recentEnrollments;
    private List<SubmissionResponse> recentSubmissions;
}
