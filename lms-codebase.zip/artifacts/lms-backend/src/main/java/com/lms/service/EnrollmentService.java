package com.lms.service;

import com.lms.dto.request.ProgressRequest;
import com.lms.dto.response.EnrollmentResponse;
import com.lms.entity.*;
import com.lms.repository.EnrollmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final CourseService courseService;
    private final UserService userService;

    public EnrollmentResponse enroll(Long courseId) {
        User student = userService.getCurrentUser();
        Course course = courseService.findCourseById(courseId);
        if (enrollmentRepository.existsByStudentAndCourse(student, course)) {
            throw new RuntimeException("Already enrolled in this course");
        }
        Enrollment enrollment = Enrollment.builder()
                .student(student)
                .course(course)
                .build();
        return EnrollmentResponse.from(enrollmentRepository.save(enrollment));
    }

    public List<EnrollmentResponse> getMyEnrollments() {
        User student = userService.getCurrentUser();
        return enrollmentRepository.findByStudent(student)
                .stream().map(EnrollmentResponse::from).toList();
    }

    public List<EnrollmentResponse> getCourseEnrollments(Long courseId) {
        Course course = courseService.findCourseById(courseId);
        return enrollmentRepository.findByCourse(course)
                .stream().map(EnrollmentResponse::from).toList();
    }

    public EnrollmentResponse updateProgress(Long enrollmentId, ProgressRequest request) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollment.setProgressPercentage(request.getProgressPercentage());
        if (request.getProgressPercentage() >= 100.0) {
            enrollment.setStatus(EnrollmentStatus.COMPLETED);
            enrollment.setCompletedAt(LocalDateTime.now());
        }
        return EnrollmentResponse.from(enrollmentRepository.save(enrollment));
    }

    public void dropEnrollment(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollment.setStatus(EnrollmentStatus.DROPPED);
        enrollmentRepository.save(enrollment);
    }
}
