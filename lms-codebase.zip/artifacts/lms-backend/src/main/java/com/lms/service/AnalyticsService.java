package com.lms.service;

import com.lms.dto.response.*;
import com.lms.entity.CourseStatus;
import com.lms.entity.User;
import com.lms.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final UserRepository userRepository;
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final SubmissionRepository submissionRepository;
    private final AssignmentRepository assignmentRepository;
    private final UserService userService;
    private final CourseService courseService;

    public AnalyticsOverviewResponse getOverview() {
        long totalStudents = userRepository.countByRole(com.lms.entity.Role.STUDENT);
        long totalInstructors = userRepository.countByRole(com.lms.entity.Role.INSTRUCTOR);
        long totalCourses = courseRepository.count();
        long publishedCourses = courseRepository.countByStatus(CourseStatus.PUBLISHED);
        long totalEnrollments = enrollmentRepository.count();
        long completedEnrollments = enrollmentRepository.countCompleted();
        double completionRate = totalEnrollments > 0
                ? (double) completedEnrollments / totalEnrollments * 100 : 0;

        Map<String, Long> coursesByCategory = new HashMap<>();
        courseRepository.countByCategory().forEach(row ->
                coursesByCategory.put((String) row[0], (Long) row[1]));

        return AnalyticsOverviewResponse.builder()
                .totalStudents(totalStudents)
                .totalInstructors(totalInstructors)
                .totalCourses(totalCourses)
                .publishedCourses(publishedCourses)
                .totalEnrollments(totalEnrollments)
                .completedEnrollments(completedEnrollments)
                .completionRate(completionRate)
                .coursesByCategory(coursesByCategory)
                .build();
    }

    public StudentAnalyticsResponse getStudentAnalytics(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        List<EnrollmentResponse> enrollments = enrollmentRepository.findByStudent(student)
                .stream().map(EnrollmentResponse::from).toList();
        long completedCourses = enrollments.stream()
                .filter(e -> e.getStatus().name().equals("COMPLETED")).count();
        double avgProgress = enrollmentRepository.avgProgressByStudent(student) != null
                ? enrollmentRepository.avgProgressByStudent(student) : 0.0;
        Double avgScore = submissionRepository.avgScoreByStudent(student);
        long gradedSubmissions = submissionRepository.countGradedByStudent(student);
        List<SubmissionResponse> recentSubs = submissionRepository.findByStudentOrderBySubmittedAtDesc(student)
                .stream().limit(5).map(SubmissionResponse::from).toList();

        return StudentAnalyticsResponse.builder()
                .studentId(studentId)
                .studentName(student.getFirstName() + " " + student.getLastName())
                .totalEnrollments(enrollments.size())
                .completedCourses((int) completedCourses)
                .averageProgress(avgProgress)
                .averageScore(avgScore)
                .gradedSubmissions(gradedSubmissions)
                .recentEnrollments(enrollments.stream().limit(5).toList())
                .recentSubmissions(recentSubs)
                .build();
    }

    public StudentAnalyticsResponse getMyAnalytics() {
        User current = userService.getCurrentUser();
        return getStudentAnalytics(current.getId());
    }

    public CourseAnalyticsResponse getCourseAnalytics(Long courseId) {
        var course = courseService.findCourseById(courseId);
        long totalEnrollments = enrollmentRepository.countByCourse(course);
        long completedEnrollments = enrollmentRepository.findByCourse(course).stream()
                .filter(e -> e.getStatus().name().equals("COMPLETED")).count();
        double completionRate = totalEnrollments > 0
                ? (double) completedEnrollments / totalEnrollments * 100 : 0;
        Double avgScore = submissionRepository.avgScoreByCourse(courseId);
        int totalAssignments = assignmentRepository.findByCourse(course).size();
        long totalSubmissions = assignmentRepository.findByCourse(course).stream()
                .mapToLong(a -> a.getSubmissions().size()).sum();

        return CourseAnalyticsResponse.builder()
                .courseId(courseId)
                .courseTitle(course.getTitle())
                .totalEnrollments(totalEnrollments)
                .completedEnrollments(completedEnrollments)
                .completionRate(completionRate)
                .averageScore(avgScore)
                .totalAssignments(totalAssignments)
                .totalSubmissions(totalSubmissions)
                .build();
    }
}
