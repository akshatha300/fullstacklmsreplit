package com.lms.repository;

import com.lms.entity.Assignment;
import com.lms.entity.Submission;
import com.lms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByAssignment(Assignment assignment);
    List<Submission> findByStudent(User student);
    Optional<Submission> findByAssignmentAndStudent(Assignment assignment, User student);

    @Query("SELECT AVG(s.score) FROM Submission s WHERE s.student = :student AND s.score IS NOT NULL")
    Double avgScoreByStudent(@Param("student") User student);

    @Query("SELECT AVG(s.score) FROM Submission s WHERE s.assignment.course.id = :courseId AND s.score IS NOT NULL")
    Double avgScoreByCourse(@Param("courseId") Long courseId);

    @Query("SELECT s FROM Submission s WHERE s.student = :student ORDER BY s.submittedAt DESC")
    List<Submission> findByStudentOrderBySubmittedAtDesc(@Param("student") User student);

    @Query("SELECT COUNT(s) FROM Submission s WHERE s.student = :student AND s.score IS NOT NULL")
    long countGradedByStudent(@Param("student") User student);
}
