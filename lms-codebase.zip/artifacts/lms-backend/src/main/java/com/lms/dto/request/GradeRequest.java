package com.lms.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class GradeRequest {
    @NotNull
    private Double score;
    private String feedback;
}
